<footer>
   <div class="container">
      <div class="ft-logo">
         <?php the_custom_logo();?>
      </div>
      <!--ft-logo end-->
      <div class="clearfix"></div>
   </div>
</footer>
<!--footer end-->
</div><!--theme-layout end-->
<?php wp_footer()?>
</body>
</html>