<form role="search" method="get" action="<?php echo home_url( '/news' ); ?>">
	<input type="text" placeholder="Search" value="<?php echo get_search_query() ?>" name="" content="search"/>
</form>