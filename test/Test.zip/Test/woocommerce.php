<?php 
get_header();
if ( have_posts() ) : ?>

<div class="container">
<?php woocommerce_content(); ?>
</div>

<?php endif; 

get_footer();?>