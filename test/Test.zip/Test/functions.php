<?php 
function load_css(){
wp_register_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css',array(),false,'all');
wp_enqueue_style( 'bootstrap');
wp_register_style( 'slick', get_template_directory_uri() . '/css/slick.css',array(),false,'all');
wp_enqueue_style( 'slick');
wp_register_style( 'responsive', get_template_directory_uri() . '/css/responsive.css',array(),false,'all');
wp_enqueue_style( 'responsive');
wp_register_style( 'slick-theme', get_template_directory_uri() . '/css/slick-theme.css',array(),false,'all');
wp_enqueue_style( 'slick-theme');
wp_register_style( 'style', get_template_directory_uri() . '/css/style.css',array(),false,'all');
wp_enqueue_style( 'style');
}
add_action('wp_enqueue_scripts', 'load_css');
function load_js(){
wp_register_script('jqueryjs', get_template_directory_uri() . '/js/jquery.min.js','jquery',false,true);
wp_enqueue_script( 'jqueryjs');
wp_register_script('bootstrapjs', get_template_directory_uri() . '/js/bootstrap.min.js','jquery',false,true);
wp_enqueue_script( 'bootstrapjs');
wp_register_script('popper', get_template_directory_uri() . '/js/popper.js','jquery',false,true);
wp_enqueue_script( 'poppers');
wp_register_script('script', get_template_directory_uri() . '/js/script.js','jquery',false,true);
wp_enqueue_script( 'script');
wp_register_script('slick', get_template_directory_uri() . '/js/slick.js','jquery',false,true);
wp_enqueue_script( 'slick');
}
add_action('wp_enqueue_scripts', 'load_js');
/*
==========================================
Theme Support
==========================================
*/
function Test_theme_setup(){
add_theme_support('menus');
}
add_action('init','Test_theme_setup');
add_theme_support('custom-background');
add_theme_support('custom-header');
add_theme_support('post-thumbnails');
add_theme_support('post-formats',array('aside','image','video'));
add_filter( 'widget_meta_poweredby', '__return_empty_string' );
add_theme_support('html5',
array('search-form')
);
add_theme_support('custom-logo' );
register_nav_menus(
array(
'top-menu' => __('top manu','Custom_theme'),
)
);
/*
==========================================
Custom Logo
==========================================
*/
function Test_theme_logo() {
$defaults = array(
'height'      => 100,
'width'       => 400,
'flex-height' => true,
'flex-width'  => true,
'header-text' => array( 'site-title', 'site-description' ),
);
add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'Test_theme_logo' );
/*
==========================================
Custom Post Type
==========================================
*/
function Test_post_type (){
$labels = array(
'name' => 'News',
'singular_name' => 'News',
'add_new' => 'Add News Blog',
'all_items' => 'All Items',
'add_new_item' => 'Add Item',
'edit_item' => 'Edit Item',
'new_item' => 'New Item',
'view_item' => 'View Item',
'search_item' => 'Search News',
'not_found' => 'No items found',
'not_found_in_trash' => 'No items found in trash',
'parent_item_colon' => 'Parent Item'
);
$args = array(
'labels' => $labels,
'public' => true,
'has_archive' => true,
'publicly_queryable' => true,
'query_var' => true,
'rewrite' => true,
'capability_type' => 'post',
'hierarchical' => false,
'supports' => array(
'title',
'editor',
'excerpt',
'thumbnail',
'revisions',
),
'taxonomies' => array('category', 'post_tag'),
'menu_position' => 5,
'exclude_from_search' => false
);
register_post_type('News',$args);
}
add_action('init','Test_post_type');
/*
==========================================
Sidebar
==========================================
*/
function Test_widget_setup() {
register_sidebar(
array(  
'name'  => 'header-left',
'id'  => 'header-left',
'class' => 'custom',
'description' => 'Standard Sidebar',
'before_widget' => '
<aside id="%1$s" class="widget %2$s">',
   'after_widget'  => '
</aside>
',
'before_title'  => '
<h1 class="widget-title">',
   'after_title'   => '
</h1>
',
)
);
}
add_action('widgets_init','Test_widget_setup');  
/**
==================================
required plugins
==================================
*/
function Test_required() {
$missing = array();
$plugins = array(
'advanced-custom-fields/acf.php' => 'Advanced Custom Fields',
'hello-world/hello-world.php' => 'hello-world for shortcode',
);
foreach($plugins as $plugin => $name) {
if(!is_plugin_active($plugin) )
$missing[$plugin] = $name;
}
return $missing;
}
/**
==================================
Check for theme required plugins
==================================
*/
function Test_theme_dependencies() {
$plugins = Test_required();
foreach($plugins as $plugin => $name) {
if(!is_plugin_active($plugin) )
echo '
<div class="error">
   <p>' . sprintf(__( 'Warning: The Test theme requires the plugin %s.', 'Test'), $name ) . ' <a href="'.admin_url().'plugins.php">' . sprintf(__( 'View Plugins', 'Test'), $name ) . '</a></p>
</div>
';
}
}
add_action( 'admin_notices', 'Test_theme_dependencies' );
function Test_add_woocommerce_support()
{
add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'Test_add_woocommerce_support' );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart');
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart');
/**
==================================
Auto page Creation 
==================================
*/
wp_register_theme_activation_hook('Test', 'Test_theme_activate');
wp_register_theme_deactivation_hook('Test', 'Test_theme_deactivate');
function wp_register_theme_activation_hook($code, $function) {
$optionKey="theme_is_activated_" . $code;
if(!get_option($optionKey)) {
call_user_func($function);
update_option($optionKey , 1);
}
}
function wp_register_theme_deactivation_hook($code, $function)
{
// store function in code specific global
$GLOBALS["wp_register_theme_deactivation_hook_function" . $code]=$function;
$fn=create_function('$theme', ' call_user_func($GLOBALS["wp_register_theme_deactivation_hook_function' . $code . '"]); delete_option("theme_is_activated_' . $code. '");');
add_action("switch_theme", $fn);
}
function Test_theme_activate()
{
$default_pages = array(
array(
'title' => 'Home',
'priority' => 105,
),
array(
'title' => 'About Us',
'template' => 'about_us.php',
'priority' => 110
),
array(
'title' => 'History',
'template' => 'history.php',
'priority' => 115
),
array(
'title' => 'Services',
'template' => 'services.php',
'priority' => 120
),
array(
'title' => 'Portfolio',
'template' => 'portfolio.php',
'priority' => 125
),
array(
'title' => 'Contact',
'template' => 'contact.php',
'priority' => 130
)
);
$existing_pages = get_pages();
$existing_titles = array();
foreach ($existing_pages as $page) 
{
$existing_titles[] = $page->post_title;
}
foreach ($default_pages as $new_page) 
{
if( !in_array( $new_page['title'], $existing_titles ) )
{
// create post object
$add_default_pages = array(
'post_title' => $new_page['title'],
'post_status' => 'publish',
'post_type' => 'page'
);
// insert the post into the database
$result = wp_insert_post($add_default_pages);   
}
}
}
function Test_theme_deactivate() 
{
// code to execute on theme deactivation
}
/**
=============================
Deleting post “Hello World” 
=============================
*/
wp_delete_post(1);
/**
=============================
Unregister all widgets
=============================
*/
function unregister_default_widgets() {
unregister_widget('WP_Widget_Pages');
unregister_widget('WP_Widget_Calendar');
unregister_widget('WP_Widget_Archives');
unregister_widget('WP_Widget_Links');
unregister_widget('WP_Widget_Meta');
unregister_widget('WP_Widget_Text');
unregister_widget('WP_Widget_Categories');
unregister_widget('WP_Widget_Recent_Posts');
unregister_widget('WP_Widget_Recent_Comments');
unregister_widget('WP_Widget_RSS');
unregister_widget('WP_Widget_Tag_Cloud');
unregister_widget('WP_Nav_Menu_Widget');
unregister_widget('Twenty_Eleven_Ephemera_Widget');
}
add_action('widgets_init', 'unregister_default_widgets', 11);
/**
==================================
removes the default sorting 
==================================
*/
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
/**
==================================
Data of CPT 
==================================
*/
function my_acf_add_local_field_groups() {

acf_add_local_field_group(array(
'key' => 'group_5daee28dd76a4',
'title' => 'Banners',
'fields' => array(
array(
'key' => 'field_5daee30f2f03b',
'label' => '1st banner',
'name' => '1st_banner',
'type' => 'group',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'layout' => 'block',
'sub_fields' => array(
array(
'key' => 'field_5daee3402f03c',
'label' => 'Main title text',
'name' => 'main_title_text',
'type' => 'text',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'default_value' => '',
'placeholder' => '',
'prepend' => '',
'append' => '',
'maxlength' => '',
),
array(
'key' => 'field_5daee3752f03d',
'label' => 'link',
'name' => 'link',
'type' => 'link',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'return_format' => 'url',
),
array(
'key' => 'field_5daee39a2f03e',
'label' => 'Link text',
'name' => 'link_text',
'type' => 'text',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'default_value' => '',
'placeholder' => '',
'prepend' => '',
'append' => '',
'maxlength' => '',
),
array(
'key' => 'field_5daee3b42f03f',
'label' => 'Publish Date',
'name' => 'publish_date',
'type' => 'date_picker',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'display_format' => 'F j, Y',
'return_format' => 'F j, Y',
'first_day' => 1,
),
),
),
array(
'key' => 'field_5daee3fd5fdf8',
'label' => '2nd banner',
'name' => '2nd_banner',
'type' => 'group',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'layout' => 'block',
'sub_fields' => array(
array(
'key' => 'field_5daee3fd5fdf9',
'label' => 'Main title text',
'name' => 'main_title_text',
'type' => 'text',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'default_value' => '',
'placeholder' => '',
'prepend' => '',
'append' => '',
'maxlength' => '',
),
array(
'key' => 'field_5daee3fd5fdfa',
'label' => 'link',
'name' => 'link',
'type' => 'link',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'return_format' => 'url',
),
array(
'key' => 'field_5daee3fd5fdfb',
'label' => 'Link text',
'name' => 'link_text',
'type' => 'text',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'default_value' => '',
'placeholder' => '',
'prepend' => '',
'append' => '',
'maxlength' => '',
),
array(
'key' => 'field_5daee3fd5fdfc',
'label' => 'Publish Date',
'name' => 'publish_date',
'type' => 'date_picker',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'display_format' => 'F j, Y',
'return_format' => 'F j, Y',
'first_day' => 1,
),
),
),
array(
'key' => 'field_5daee40e895af',
'label' => '3rd banner',
'name' => '3rd_banner',
'type' => 'group',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'layout' => 'block',
'sub_fields' => array(
array(
'key' => 'field_5daee40e895b0',
'label' => 'Main title text',
'name' => 'main_title_text',
'type' => 'text',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'default_value' => '',
'placeholder' => '',
'prepend' => '',
'append' => '',
'maxlength' => '',
),
array(
'key' => 'field_5daee40e895b1',
'label' => 'link',
'name' => 'link',
'type' => 'link',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'return_format' => 'url',
),
array(
'key' => 'field_5daee40e895b2',
'label' => 'Link text',
'name' => 'link_text',
'type' => 'text',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'default_value' => '',
'placeholder' => '',
'prepend' => '',
'append' => '',
'maxlength' => '',
),
array(
'key' => 'field_5daee40e895b3',
'label' => 'Publish Date',
'name' => 'publish_date',
'type' => 'date_picker',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'display_format' => 'F j, Y',
'return_format' => 'F j, Y',
'first_day' => 1,
),
),
),
array(
'key' => 'field_5daee4589994a',
'label' => 'About',
'name' => 'about',
'type' => 'group',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'layout' => 'block',
'sub_fields' => array(
array(
'key' => 'field_5daee47a9994b',
'label' => 'About Text',
'name' => 'about_text_area',
'type' => 'wysiwyg',
'instructions' => '',
'required' => 0,
'conditional_logic' => 0,
'wrapper' => array(
'width' => '',
'class' => '',
'id' => '',
),
'default_value' => '',
'tabs' => 'all',
'toolbar' => 'full',
'media_upload' => 1,
'delay' => 0,
),
),
),
),
'location' => array(
array(
array(
'param' => 'page_type',
'operator' => '==',
'value' => 'front_page',
),
),
),
'menu_order' => 0,
'position' => 'normal',
'style' => 'default',
'label_placement' => 'top',
'instruction_placement' => 'label',
'hide_on_screen' => '',
'active' => true,
'description' => '',
));
}

add_action('acf/init', 'my_acf_add_local_field_groups');