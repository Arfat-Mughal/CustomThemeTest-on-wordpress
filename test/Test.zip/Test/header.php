<!DOCTYPE html>
<html>
   <head>
      <title><?php bloginfo('name');?></title>
      <?php wp_head();?>
   </head>
   <body <?php body_class();?>>
      <div class="theme-layout">
      <header>
         <div class="container">
            <div class="logo">
               <?php the_custom_logo(); ?>
            </div>
            <!--logo end-->
            <div class="contact-info">
               <h3><?php bloginfo('description'); ?></h3>
            </div>
            <!--contact-info end-->
            <div class="menu-btn">
               <a href="#" title="">
               <span class="bar1"></span>
               <span class="bar2"></span>
               <span class="bar3"></span>
               </a>
            </div>
            <!--menu-btn end-->
            <div class="clearfix"></div>
         </div>
      </header>
      <!--header end-->
      <section class="navi-sec">
         <div class="container">
            <form class="search_form">
                <?php dynamic_sidebar( 'header-left' ); ?>
            </form>
            <!--search_form end-->
            <nav>
               <?php 
                  wp_nav_menu(
                    array(
                      'theme_loaction' => 'top-menu',
                      'container' => 'ul'
                    )
                  );?>
            </nav>
            <!--navigation end-->
            <div class="clearfix"></div>
         </div>
      </section>
      <!--navi-sec end-->