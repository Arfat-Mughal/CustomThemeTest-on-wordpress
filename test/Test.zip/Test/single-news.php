<?php get_header(); ?>
<?php 
   if( have_posts() ):
      
      while( have_posts() ): the_post(); ?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
   <section class="main-content">
      <div class="container">
         <div class="blog-section">
            <h3>Our News</h3>
            <div class="blog-posts">
               <div class="blog-post">
                  <div class="post-img">
                     <?php if( has_post_thumbnail() ): 
                        the_post_thumbnail('thumbnail'); 
                        endif; ?>
                  </div>
                  <!--post-img end-->
                  <div class="post-info">
                     <span class="posted-date"><?php the_time('F j, Y')?></span>
                     <p><?php the_content();?></p>
                  </div>
                  <!--post-info end-->
               </div>
               <!--blog-post end-->
            </div>
            <!--blog-posts end-->
         </div>
         <!--blog-section end-->
      </div>
      <div class="clearfix"></div>
   </section>
</article>
<?php endwhile;
   endif;
         
   ?>
<?php get_footer();?>